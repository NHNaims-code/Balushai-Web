"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 9113:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "c": () => (/* binding */ AllProducts),
/* harmony export */   "bm": () => (/* binding */ SingleProduct)
/* harmony export */ });
/* unused harmony export SellerProducts */
/* harmony import */ var _xhr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4673);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_xhr__WEBPACK_IMPORTED_MODULE_0__]);
_xhr__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

function AllProducts() {
    return (0,_xhr__WEBPACK_IMPORTED_MODULE_0__/* .Get */ .dX)("products");
}
function SellerProducts(path) {
    return Get(path);
}
function SingleProduct(path) {
    return (0,_xhr__WEBPACK_IMPORTED_MODULE_0__/* .Get */ .dX)(path);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1306:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ HeroSection)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/home/HeroCategory.jsx


function HeroCategory() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "rounded-lg bg-white p-4 my-4 relative border-b-2",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "font-semibold border-b-2 pb-4 mb-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "fa-regular fa-list mr-4"
                    }),
                    "Category"
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "py-3 border-b group hover:cursor-pointer hover:text-[#D23E41]",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "mr-2 fa-light fa-person-dress-simple"
                                        }),
                                        " Women`'s Fashion"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "transition-all duration-300 absolute opacity-0 -z-40 shadow-lg left-[100%] group-hover:z-40 group-hover:opacity-100 top-0 w-[780px] h-[400px] bg-white flex justify-center items-center flex-col text-5xl rounded-sm",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-sm",
                                            children: " Women`'s Fashion"
                                        }),
                                        "Details Here"
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "py-3 border-b group hover:cursor-pointer hover:text-[#D23E41]",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "mr-2 fa-light fa-person-simple"
                                        }),
                                        " Men`'s Fashion"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "transition-all duration-300 absolute opacity-0 -z-40 shadow-lg left-[100%] group-hover:z-40 group-hover:opacity-100 top-0 w-[780px] h-[400px] bg-white flex justify-center items-center flex-col text-5xl rounded-sm",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-sm",
                                            children: " Men`'s Fashion"
                                        }),
                                        "Details Here"
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "py-3 border-b group hover:cursor-pointer hover:text-[#D23E41]",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "mr-2 fa-light fa-mobile"
                                        }),
                                        " Phones & Telecommunications"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "transition-all duration-300 absolute opacity-0 -z-40 shadow-lg left-[100%] group-hover:z-40 group-hover:opacity-100 top-0 w-[780px] h-[400px] bg-white flex justify-center items-center flex-col text-5xl rounded-sm",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-sm",
                                            children: " Phones & Telecommunications"
                                        }),
                                        "Details Here"
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "py-3 border-b group hover:cursor-pointer hover:text-[#D23E41]",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "mr-2 fa-light fa-laptop"
                                        }),
                                        " Computer, Office & Security"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "transition-all duration-300 absolute opacity-0 -z-40 shadow-lg left-[100%] group-hover:z-40 group-hover:opacity-100 top-0 w-[780px] h-[400px] bg-white flex justify-center items-center flex-col text-5xl rounded-sm",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-sm",
                                            children: " Computer, Office & Security"
                                        }),
                                        "Details Here"
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "py-3 border-b group hover:cursor-pointer hover:text-[#D23E41]",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "mr-2 fa-light fa-camera"
                                        }),
                                        " Consumer Electronics"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "transition-all duration-300 absolute opacity-0 -z-40 shadow-lg left-[100%] group-hover:z-40 group-hover:opacity-100 top-0 w-[780px] h-[400px] bg-white flex justify-center items-center flex-col text-5xl rounded-sm",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-sm",
                                            children: " Consumer Electronics"
                                        }),
                                        "Details Here"
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "py-3 border-b group hover:cursor-pointer hover:text-[#D23E41]",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "mr-2 fa-light fa-gem"
                                        }),
                                        " Jewelry & Watches"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "transition-all duration-300 absolute opacity-0 -z-40 shadow-lg left-[100%] group-hover:z-40 group-hover:opacity-100 top-0 w-[780px] h-[400px] bg-white flex justify-center items-center flex-col text-5xl rounded-sm",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-sm",
                                            children: " Jewelry & Watches"
                                        }),
                                        "Details Here"
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "py-3 border-b group hover:cursor-pointer hover:text-[#D23E41]",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "mr-2 fa-light fa-dog-leashed"
                                        }),
                                        " Home, Pet & Application"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "transition-all duration-300 absolute opacity-0 -z-40 shadow-lg left-[100%] group-hover:z-40 group-hover:opacity-100 top-0 w-[780px] h-[400px] bg-white flex justify-center items-center flex-col text-5xl rounded-sm",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-sm",
                                            children: " Home, Pet & Application"
                                        }),
                                        "Details Here"
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "py-3 border-b group hover:cursor-pointer hover:text-[#D23E41]",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "mr-2 fa-light fa-bag-shopping"
                                        }),
                                        " Bags & Shoes"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "transition-all duration-300 absolute opacity-0 -z-40 shadow-lg left-[100%] group-hover:z-40 group-hover:opacity-100 top-0 w-[780px] h-[400px] bg-white flex justify-center items-center flex-col text-5xl rounded-sm",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-sm",
                                            children: " Bags & Shoes"
                                        }),
                                        "Details Here"
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};

// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(8096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./components/home/HeroOfferSlider.jsx






function HeroOfferSlider() {
    /*  const PrevArrowButton = (props) => {
      console.log(props)
      const {className, onClick} = props
      return(<div 
        className={className} 
        onClick={onClick}>
          <i className={`fa-light fa-chevron-right text-white`}></i>
        </div>)
    }

    const NextArrowButton = (props) => {
      const {className, onClick} = props
      return(<div className={className} onClick={onClick} style={{color: 'white'}}>Next</div>)
    } */ const settings = {
        dots: false,
        lazyLoad: true,
        autoplay: true,
        infinite: true,
        speed: 300,
        slidesToShow: 4,
        slidesToScroll: 1,
        // prevArrow:<PrevArrowButton/>,
        // nextArrow:<NextArrowButton/>,
        customPaging: (index)=>{
            return /*#__PURE__*/ jsx_runtime_.jsx("div", {});
        },
        dotsClass: "slick-dots custom-indicator"
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_slick_default()), {
            ...settings,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "bg-white my-4 mx-1 p-1 rounded-lg shadow-md flex flex-col",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "h-32 bg-center bg-cover bg-no-repeat",
                                style: {
                                    backgroundImage: `url('/home-slider-images/slide1.webp')`
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-semibold text-center",
                                children: "Price: $100"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "bg-[#D23E41] text-white px-2 py-1 text-sm mt-1",
                                children: "Buy Now"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "bg-white my-4 mx-1 p-1 rounded-lg shadow-md flex flex-col",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "h-32 bg-center bg-cover bg-no-repeat",
                                style: {
                                    backgroundImage: `url('/home-slider-images/slide2.webp')`
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-semibold text-center",
                                children: "Price: $100"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "bg-[#D23E41] text-white px-2 py-1 text-sm mt-1",
                                children: "Buy Now"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "bg-white my-4 mx-1 p-1 rounded-lg shadow-md flex flex-col",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "h-32 bg-center bg-cover bg-no-repeat",
                                style: {
                                    backgroundImage: `url('/home-slider-images/slide3.webp')`
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-semibold text-center",
                                children: "Price: $100"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "bg-[#D23E41] text-white px-2 py-1 text-sm mt-1",
                                children: "Buy Now"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "bg-white my-4 mx-1 p-1 rounded-lg shadow-md flex flex-col",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "h-32 bg-center bg-cover bg-no-repeat",
                                style: {
                                    backgroundImage: `url('/home-slider-images/slide4.webp')`
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-semibold text-center",
                                children: "Price: $100"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "bg-[#D23E41] text-white px-2 py-1 text-sm mt-1",
                                children: "Buy Now"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "bg-white my-4 mx-1 p-1 rounded-lg shadow-md flex flex-col",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "h-32 bg-center bg-cover bg-no-repeat",
                                style: {
                                    backgroundImage: `url('/home-slider-images/slide4.webp')`
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-semibold text-center",
                                children: "Price: $100"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "bg-[#D23E41] text-white px-2 py-1 text-sm mt-1",
                                children: "Buy Now"
                            })
                        ]
                    })
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./components/home/HeroOffer.jsx



function TopOffer() {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 mt-10",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "grid grid-cols-3 gap-4",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: " p-4",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                            className: "text-xl font-semibold text-white",
                            children: "Welcome newcommers!"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "mt-4 text-white",
                            children: "Get items for $1 or get a $5 copon!"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: " col-span-2",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(HeroOfferSlider, {})
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: ./components/home/HeroRightSection.jsx




function HeroRightSection() {
    const userData = (0,external_react_redux_.useSelector)((state)=>{
        var ref;
        return state === null || state === void 0 ? void 0 : (ref = state.user) === null || ref === void 0 ? void 0 : ref.data;
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: " rounded-lg bg-white mt-4 hidden xl:flex flex-col mb-4",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center flex-col mt-8",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "fa-solid fa-circle-user text-5xl"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "font-semibold mt-2",
                        children: "Welcome to Balushai"
                    })
                ]
            }),
            (userData === null || userData === void 0 ? void 0 : userData.name) ? /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                className: "text-center border-y-1 shadow-sm py-2 text-xl mt-2",
                children: userData === null || userData === void 0 ? void 0 : userData.name
            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "p-4 flex justify-around",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        passHref: true,
                        href: "/auth/sign-up",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "bg-[#D23E41] text-white h-12 w-24 rounded-2xl",
                            children: "Join"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        passHref: true,
                        href: "/auth/sign-in",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "bg-[#D23E41] text-white h-12 w-24 rounded-2xl",
                            children: "Sign in"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "h-full bg-gray-200 m-4 flex justify-center items-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: "",
                    children: "Offer Here"
                })
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/home/HeroSlider.jsx






function HeroSlider() {
    const PrevArrowButton = (props)=>{
        const { className , onClick  } = props;
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: className,
            onClick: onClick,
            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                className: `fa-light fa-chevron-right text-white`
            })
        });
    };
    const NextArrowButton = (props)=>{
        const { className , onClick  } = props;
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: className,
            onClick: onClick,
            style: {
                color: "white"
            },
            children: "Next"
        });
    };
    const settings = {
        dots: true,
        lazyLoad: true,
        autoplay: true,
        infinite: true,
        speed: 300,
        slidesToShow: 1,
        slidesToScroll: 1,
        prevArrow: /*#__PURE__*/ jsx_runtime_.jsx(PrevArrowButton, {}),
        nextArrow: /*#__PURE__*/ jsx_runtime_.jsx(NextArrowButton, {}),
        customPaging: (index)=>{
            return /*#__PURE__*/ jsx_runtime_.jsx("div", {});
        },
        dotsClass: "slick-dots custom-indicator"
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_slick_default()), {
            ...settings,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "h-[320px] bg-white shadow-md bg-no-repeat bg-cover rounded-md",
                        style: {
                            backgroundImage: `url('/home-slider-images/slide1.webp')`
                        }
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "h-[320px] bg-white shadow-md bg-no-repeat bg-cover rounded-md",
                        style: {
                            backgroundImage: `url('/home-slider-images/slide2.webp')`
                        }
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "h-[320px] bg-white shadow-md bg-no-repeat bg-cover rounded-md",
                        style: {
                            backgroundImage: `url('/home-slider-images/slide3.webp')`
                        }
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "h-[320px] bg-white shadow-md bg-no-repeat bg-cover rounded-md",
                        style: {
                            backgroundImage: `url('/home-slider-images/slide4.webp')`
                        }
                    })
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./components/home/HeroSection.jsx






function HeroSection() {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "container mx-auto",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "grid xl:grid-cols-5 grid-cols-4 gap-4",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(HeroCategory, {}),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "col-span-3 mt-4 rounded-lg mb-4",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(HeroSlider, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(TopOffer, {})
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(HeroRightSection, {})
            ]
        })
    });
};


/***/ }),

/***/ 6506:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ProductCard)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);




function ProductCard({ data  }) {
    var ref, ref1, ref2, ref3, ref4, ref5, ref6, ref7, ref8;
    console.log("from product card: ", data);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
        passHref: true,
        href: `/product/${data === null || data === void 0 ? void 0 : data.slug}`,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "transition-all duration-150 cursor-pointer rounded-md overflow-hidden shadow-md hover:shadow-lg",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "bg-white",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                            alt: "image",
                            src: (ref1 = (ref = data === null || data === void 0 ? void 0 : data.variant_stock_price[0]) === null || ref === void 0 ? void 0 : ref.images[0]) === null || ref1 === void 0 ? void 0 : ref1.url,
                            width: "100%",
                            height: "100%",
                            layout: "responsive",
                            objectFit: "contain"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "p-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                className: "text-sm h-6 whitespace-nowrap overflow-hidden text-ellipsis",
                                children: data === null || data === void 0 ? void 0 : data.product_name
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    "BDT",
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "text-sm ml-1",
                                        children: [
                                            "\u09F3",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-xl font-semibold",
                                                children: parseInt((ref3 = (ref2 = data === null || data === void 0 ? void 0 : data.variant_stock_price[0]) === null || ref2 === void 0 ? void 0 : ref2.sizes[0]) === null || ref3 === void 0 ? void 0 : (ref4 = ref3.pricing) === null || ref4 === void 0 ? void 0 : ref4.special_price).toLocaleString()
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "ml-2",
                                        children: [
                                            "\u09F3",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "line-through",
                                                children: parseInt((ref6 = (ref5 = data === null || data === void 0 ? void 0 : data.variant_stock_price[0]) === null || ref5 === void 0 ? void 0 : ref5.sizes[0]) === null || ref6 === void 0 ? void 0 : (ref7 = ref6.pricing) === null || ref7 === void 0 ? void 0 : ref7.price).toLocaleString()
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mt-1 text-sm",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "text-md",
                                        children: [
                                            data === null || data === void 0 ? void 0 : (ref8 = data.orders) === null || ref8 === void 0 ? void 0 : ref8.length,
                                            " sold"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                className: "fa-solid fa-star text-amber-500 mx-2"
                                            }),
                                            data === null || data === void 0 ? void 0 : data.rating
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-sm mt-1",
                                children: "Free Shipping"
                            })
                        ]
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 889:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ProductSection)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _adapters_product__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9113);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3829);
/* harmony import */ var _ProductCard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6506);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_adapters_product__WEBPACK_IMPORTED_MODULE_2__, _utils__WEBPACK_IMPORTED_MODULE_3__]);
([_adapters_product__WEBPACK_IMPORTED_MODULE_2__, _utils__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






function ProductSection({ products =[]  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "container mx-auto mb-8 mt-8",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "text-center p-4 border-b-2 mb-4",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: "text-2xl select-all",
                    children: "Explore what you love"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "grid sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6 gap-x-4 gap-y-6",
                children: products.map((product, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductCard__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        data: product
                    }, index)
                )
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5991:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: default

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./components/home/SuperDealsCard.jsx




function SuperDealsCard_SuperDealsCard({ src  }) {
    return /*#__PURE__*/ _jsx(Link, {
        passHref: true,
        href: "/product/id",
        className: "no-underline",
        children: /*#__PURE__*/ _jsxs("div", {
            className: "cursor-pointer",
            children: [
                /*#__PURE__*/ _jsxs("div", {
                    className: "relative",
                    children: [
                        /*#__PURE__*/ _jsx(Image, {
                            alt: "image",
                            src: src,
                            width: "100%",
                            height: "100%",
                            layout: "responsive",
                            objectFit: "cover"
                        }),
                        /*#__PURE__*/ _jsx("div", {
                            className: "absolute top-0 left-0 shadow-sm bg-[#D23E41] p-1 text-white px-2 rounded-r",
                            children: "82% off"
                        })
                    ]
                }),
                /*#__PURE__*/ _jsxs("div", {
                    children: [
                        /*#__PURE__*/ _jsxs("div", {
                            className: "px-1",
                            children: [
                                /*#__PURE__*/ _jsxs("span", {
                                    className: "text-[#D23E41]",
                                    children: [
                                        "$",
                                        /*#__PURE__*/ _jsx("span", {
                                            className: "text-4xl font-bold",
                                            children: "7"
                                        }),
                                        " "
                                    ]
                                }),
                                /*#__PURE__*/ _jsx("span", {
                                    className: "ml-2 line-through",
                                    children: "US $41"
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsx("p", {
                            children: "15602 orders"
                        })
                    ]
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./components/home/SuperDealsSection.jsx




function SuperDealsSection() {
    return /*#__PURE__*/ _jsxs("div", {
        className: "container shadow-lg rounded-md mx-auto mb-4 bg-white p-4",
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: "border-b pb-4",
                children: /*#__PURE__*/ _jsxs("div", {
                    className: "flex justify-between",
                    children: [
                        /*#__PURE__*/ _jsxs("div", {
                            className: "flex items-center",
                            children: [
                                /*#__PURE__*/ _jsxs("h1", {
                                    className: "text-xl font-bold",
                                    children: [
                                        "Super",
                                        /*#__PURE__*/ _jsx("span", {
                                            className: "text-[#D23E41]",
                                            children: "Deals"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: "ml-4",
                                    children: "Top products. Incredible prices."
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsx(Link, {
                            passHref: true,
                            href: "#",
                            children: "View more"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ _jsxs("div", {
                className: "grid sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6 gap-4 pt-4",
                children: [
                    /*#__PURE__*/ _jsx(SuperDealsCard, {
                        src: "/product-images/product1.webp"
                    }),
                    /*#__PURE__*/ _jsx(SuperDealsCard, {
                        src: "/product-images/product2.webp"
                    }),
                    /*#__PURE__*/ _jsx(SuperDealsCard, {
                        src: "/product-images/product3.webp"
                    }),
                    /*#__PURE__*/ _jsx(SuperDealsCard, {
                        src: "/product-images/product1.webp"
                    }),
                    /*#__PURE__*/ _jsx(SuperDealsCard, {
                        src: "/product-images/product3.webp"
                    }),
                    /*#__PURE__*/ _jsx(SuperDealsCard, {
                        src: "/product-images/product2.webp"
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 5293:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Banner)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);



function Banner() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "mt-4",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full h-[62px] bg-cover bg-center bg-no-repeat",
            style: {
                backgroundImage: `url('/banner-images/home-banner1.webp')`
            }
        })
    });
};


/***/ }),

/***/ 5632:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ HeroCategory)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);



function HeroCategory() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "grid grid-cols-5 gap-2 p-4 mt-12",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                    passHref: true,
                    href: "#",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xl h-12 w-12 flex justify-center items-center rounded-full text-white bg-green-500",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "fa-light fa-list"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xs mt-1",
                                children: "Categories"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                    passHref: true,
                    href: "#",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xl h-12 w-12 flex justify-center items-center rounded-full text-white bg-pink-500",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "fa-light fa-person-dress"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xs mt-1 text-center",
                                children: "Women`'s clothing"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                    passHref: true,
                    href: "#",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xl h-12 w-12 flex justify-center items-center rounded-full text-white bg-blue-500",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "fa-light fa-person-dress-simple"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xs mt-1 text-center",
                                children: "Men`'s clothing"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                    passHref: true,
                    href: "#",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xl h-12 w-12 flex justify-center items-center rounded-full text-white bg-orange-500",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "fa-light fa-mobile-button"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xs mt-1 text-center",
                                children: "Phones & Accessories"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                    passHref: true,
                    href: "#",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xl h-12 w-12 flex justify-center items-center rounded-full text-white bg-amber-500",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "fa-light fa-camera"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xs mt-1 text-center",
                                children: "Consumer Electronics"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                    passHref: true,
                    href: "#",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xl h-12 w-12 flex justify-center items-center rounded-full text-white bg-orange-500",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "fa-light fa-mobile-button"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xs mt-1 text-center",
                                children: "Phones & Accessories"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                    passHref: true,
                    href: "#",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xl h-12 w-12 flex justify-center items-center rounded-full text-white bg-blue-500",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "fa-light fa-list"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xs mt-1",
                                children: "Categories"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                    passHref: true,
                    href: "#",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xl h-12 w-12 flex justify-center items-center rounded-full text-white bg-pink-500",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "fa-light fa-person-dress"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xs mt-1 text-center",
                                children: "Women`'s clothing"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                    passHref: true,
                    href: "#",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xl h-12 w-12 flex justify-center items-center rounded-full text-white bg-blue-500",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "fa-light fa-person-dress-simple"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xs mt-1 text-center",
                                children: "Men`'s clothing"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                    passHref: true,
                    href: "#",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xl h-12 w-12 flex justify-center items-center rounded-full text-white bg-orange-500",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "fa-light fa-mobile-button"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-xs mt-1 text-center",
                                children: "Phones & Accessories"
                            })
                        ]
                    })
                })
            })
        ]
    });
};


/***/ }),

/***/ 3917:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ MobileHeroSlider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);






function MobileHeroSlider() {
    const PrevArrowButton = (props)=>{
        const { className , onClick  } = props;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: className,
            onClick: onClick,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: `fa-light fa-chevron-right text-white`
            })
        });
    };
    const NextArrowButton = (props)=>{
        const { className , onClick  } = props;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: className,
            onClick: onClick,
            style: {
                color: "white"
            },
            children: "Next"
        });
    };
    const settings = {
        dots: true,
        lazyLoad: true,
        autoplay: true,
        infinite: true,
        speed: 300,
        slidesToShow: 1,
        slidesToScroll: 1,
        prevArrow: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PrevArrowButton, {}),
        nextArrow: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NextArrowButton, {}),
        customPaging: (index)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {});
        },
        dotsClass: "slick-dots custom-indicator"
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full mt-[62px]",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_slick__WEBPACK_IMPORTED_MODULE_2___default()), {
            ...settings,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "h-[120px] bg-white bg-no-repeat bg-cover",
                        style: {
                            backgroundImage: `url('/home-slider-images/slide1.webp')`
                        }
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "h-[120px] bg-white bg-no-repeat bg-cover",
                        style: {
                            backgroundImage: `url('/home-slider-images/slide2.webp')`
                        }
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "h-[120px] bg-white bg-no-repeat bg-cover",
                        style: {
                            backgroundImage: `url('/home-slider-images/slide3.webp')`
                        }
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "h-[120px] bg-white bg-no-repeat bg-cover",
                        style: {
                            backgroundImage: `url('/home-slider-images/slide4.webp')`
                        }
                    })
                })
            ]
        })
    });
};


/***/ }),

/***/ 1575:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ MobileProductSection)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);




function MobileProductSection({ products =[]  }) {
    console.log("products: ", products);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "mt-8",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "grid grid-cols-2 gap-2 px-2",
            children: products.map((product, index)=>{
                var ref, ref1;
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "col-span-1 p-2 bg-white",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                        passHref: true,
                        href: `/product/${product === null || product === void 0 ? void 0 : product.slug}`,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    alt: "image",
                                    src: (ref1 = (ref = product === null || product === void 0 ? void 0 : product.variant_stock_price[0]) === null || ref === void 0 ? void 0 : ref.images[0]) === null || ref1 === void 0 ? void 0 : ref1.url,
                                    // src="/product-images/product1.webp"
                                    width: "100%",
                                    height: "100%",
                                    layout: "responsive",
                                    objectFit: "contain"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                    className: "text-xs",
                                    children: product.product_name
                                })
                            ]
                        })
                    })
                }, index);
            })
        })
    });
};


/***/ }),

/***/ 8618:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_home_HeroSection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1306);
/* harmony import */ var _components_home_mobile_MobileBanner__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5293);
/* harmony import */ var _components_home_mobile_MobileHeroCategory__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5632);
/* harmony import */ var _components_home_ProductCard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6506);
/* harmony import */ var _components_home_ProductSection__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(889);
/* harmony import */ var _components_home_SuperDealsSection__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5991);
/* harmony import */ var _layout_footer_Footer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5667);
/* harmony import */ var _layout_header_Header__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3265);
/* harmony import */ var _layout_mobile_footer_MobileFooter__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1283);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1664);
/* harmony import */ var _adapters_product__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9113);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _adapters_user__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4597);
/* harmony import */ var _components_home_mobile_MobileProductSection__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1575);
/* harmony import */ var _components_home_mobile_MobileHeroSlider__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3917);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_home_ProductSection__WEBPACK_IMPORTED_MODULE_6__, _layout_header_Header__WEBPACK_IMPORTED_MODULE_9__, _adapters_product__WEBPACK_IMPORTED_MODULE_12__, _adapters_user__WEBPACK_IMPORTED_MODULE_14__]);
([_components_home_ProductSection__WEBPACK_IMPORTED_MODULE_6__, _layout_header_Header__WEBPACK_IMPORTED_MODULE_9__, _adapters_product__WEBPACK_IMPORTED_MODULE_12__, _adapters_user__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


















function Home({ products  }) {
    console.log(products);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "Balushai Ecommerce"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/images/logo.jpg"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "hidden sm:block",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_home_HeroSection__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_home_ProductSection__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        products: products
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "sm:hidden",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mb-8",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_home_mobile_MobileHeroSlider__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_home_mobile_MobileHeroCategory__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_home_mobile_MobileBanner__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_home_mobile_MobileProductSection__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                            products: products
                        })
                    ]
                })
            })
        ]
    });
};
async function getServerSideProps(context) {
    const response = await (0,_adapters_product__WEBPACK_IMPORTED_MODULE_12__/* .AllProducts */ .c)();
    // const userInfo = await getUserData()
    // console.log("userInfo: ", userInfo)
    return {
        props: {
            products: response.data
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 4241:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/routing-items.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 8096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [397,676,664,675,673,745,829,297], () => (__webpack_exec__(8618)));
module.exports = __webpack_exports__;

})();