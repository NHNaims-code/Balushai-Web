"use strict";
(() => {
var exports = {};
exports.id = 915;
exports.ids = [915];
exports.modules = {

/***/ 9113:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "c": () => (/* binding */ AllProducts),
/* harmony export */   "bm": () => (/* binding */ SingleProduct)
/* harmony export */ });
/* unused harmony export SellerProducts */
/* harmony import */ var _xhr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4673);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_xhr__WEBPACK_IMPORTED_MODULE_0__]);
_xhr__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

function AllProducts() {
    return (0,_xhr__WEBPACK_IMPORTED_MODULE_0__/* .Get */ .dX)("products");
}
function SellerProducts(path) {
    return Get(path);
}
function SingleProduct(path) {
    return (0,_xhr__WEBPACK_IMPORTED_MODULE_0__/* .Get */ .dX)(path);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9984:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Description)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var html_react_parser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2905);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([html_react_parser__WEBPACK_IMPORTED_MODULE_2__]);
html_react_parser__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function Description({ data  }) {
    var ref, ref1, ref2;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "container mx-auto bg-white my-8 rounded-lg shadow-md",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text-center text-xl border-b py-4",
                        children: "Short Description"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "p-4",
                        children: data === null || data === void 0 ? void 0 : data.short_description
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "container mx-auto bg-white my-8 rounded-lg shadow-md",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text-center text-xl border-b py-4",
                        children: "Long Description"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "p-4",
                        children: (0,html_react_parser__WEBPACK_IMPORTED_MODULE_2__["default"])(data === null || data === void 0 ? void 0 : data.long_description)
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "container mx-auto bg-white my-8 p-4 rounded-lg shadow-md",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid grid-cols-6 border-x border-t",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-span-2 sm:col-span-1 border-r p-2",
                                children: "Dangerous Goods"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-span-4 sm:col-span-5 pl-4 p-2",
                                children: "None"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid grid-cols-6 border-x border-t",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-span-2 sm:col-span-1 border-r p-2",
                                children: "Package Height"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-span-4 sm:col-span-5 pl-4 p-2",
                                children: data === null || data === void 0 ? void 0 : (ref = data.package_dimensions) === null || ref === void 0 ? void 0 : ref.height
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid grid-cols-6 border-x border-t",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-span-2 sm:col-span-1 border-r p-2",
                                children: "Package Width"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-span-4 sm:col-span-5 pl-4 p-2",
                                children: data === null || data === void 0 ? void 0 : (ref1 = data.package_dimensions) === null || ref1 === void 0 ? void 0 : ref1.width
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid grid-cols-6 border-x border-t",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-span-2 sm:col-span-1 border-r p-2",
                                children: "Package Lenght"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-span-4 sm:col-span-5 pl-4 p-2",
                                children: data === null || data === void 0 ? void 0 : (ref2 = data.package_dimensions) === null || ref2 === void 0 ? void 0 : ref2.length
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid grid-cols-6 border-x border-t",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-span-2 sm:col-span-1 border-r p-2",
                                children: "Package Weight"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-span-4 sm:col-span-5 pl-4 p-2",
                                children: "1"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid grid-cols-6 border-x border-t",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-span-2 sm:col-span-1 border-r p-2",
                                children: "Warranty"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-span-4 sm:col-span-5 pl-4 p-2",
                                children: data === null || data === void 0 ? void 0 : data.warranty_type
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid grid-cols-6 border-x border-y ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-span-2 sm:col-span-1 border-r p-2",
                                children: "What is in the box"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-span-4 sm:col-span-5 pl-4 p-2",
                                children: data === null || data === void 0 ? void 0 : data.whats_in_the_box
                            })
                        ]
                    })
                ]
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5371:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ HeroSection)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _adapters_cart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1903);
/* harmony import */ var _redux_cart_cartActions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5745);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_adapters_cart__WEBPACK_IMPORTED_MODULE_4__, _redux_cart_cartActions__WEBPACK_IMPORTED_MODULE_5__]);
([_adapters_cart__WEBPACK_IMPORTED_MODULE_4__, _redux_cart_cartActions__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







function HeroSection({ data  }) {
    var ref2, ref1;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const cart = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state.cart.data
    );
    const userData = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>{
        var ref;
        return (ref = state.user) === null || ref === void 0 ? void 0 : ref.data;
    });
    const { 0: onCart , 1: setOnCart  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: currentSize , 1: setCurrentSize  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)((ref2 = data === null || data === void 0 ? void 0 : data.variant_stock_price[0]) === null || ref2 === void 0 ? void 0 : ref2.sizes[0]);
    const { 0: currentVariant , 1: setCurrentVariant  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(data === null || data === void 0 ? void 0 : data.variant_stock_price[0]);
    const { 0: quantity , 1: setQuentity  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        var ref4, ref3;
        if ((cart === null || cart === void 0 ? void 0 : (ref4 = cart.items) === null || ref4 === void 0 ? void 0 : ref4.length) == 0) {
            setOnCart(false);
        }
        cart === null || cart === void 0 ? void 0 : (ref3 = cart.items) === null || ref3 === void 0 ? void 0 : ref3.map((item)=>{
            var ref;
            if (((ref = item.product_id) === null || ref === void 0 ? void 0 : ref._id) == (data === null || data === void 0 ? void 0 : data._id)) {
                setOnCart(item);
                setQuentity(item.quantity);
            } else {
                setOnCart(false);
            }
        });
    }, [
        cart
    ]);
    // useEffect(() => {
    //   const updateCartFetcher = async () => {
    //     const updateCartItemData = {
    //     color_family: currentVariant?.color_family,
    //     size: currentSize?.size,
    //     price: currentSize?.pricing?.price,
    //     image: currentVariant?.images[0]?.url,
    //     special_price: currentSize?.pricing?.special_price || null,
    //     offer_price: currentSize.pricing?.offer_price,
    //     quantity: quantity
    //     }
    //     let updatedCartItems = []
    //     cart?.items?.map((product, index) => {
    //       if(product?._id == data?._id) {
    //         const updatedItem = {...product, ...updateCartItemData}
    //         updatedCartItems.push(updatedItem)
    //       }else{
    //         updatedCartItems.push(product)
    //       }
    //     })
    //     const result = await updateCart({...cart, items:updatedCartItems})
    //     console.log('result:', result)
    //   }
    //   updateCartFetcher()
    // }, [currentSize, currentVariant])
    const handleAddToCart = async ()=>{
        var ref, ref5, ref6, ref7;
        if (!userData) {
            router.push("/auth/sign-in");
            return 0;
        }
        const cartItem = {
            product_id: data === null || data === void 0 ? void 0 : data._id,
            vendor_id: data === null || data === void 0 ? void 0 : data.vendor_id,
            color_family: currentVariant === null || currentVariant === void 0 ? void 0 : currentVariant.color_family,
            size: currentSize === null || currentSize === void 0 ? void 0 : currentSize.size,
            price: currentSize === null || currentSize === void 0 ? void 0 : (ref = currentSize.pricing) === null || ref === void 0 ? void 0 : ref.price,
            image: (ref5 = currentVariant === null || currentVariant === void 0 ? void 0 : currentVariant.images[0]) === null || ref5 === void 0 ? void 0 : ref5.url,
            special_price: (currentSize === null || currentSize === void 0 ? void 0 : (ref6 = currentSize.pricing) === null || ref6 === void 0 ? void 0 : ref6.special_price) || null,
            offer_price: (ref7 = currentSize.pricing) === null || ref7 === void 0 ? void 0 : ref7.offer_price,
            quantity: quantity
        };
        (0,_adapters_cart__WEBPACK_IMPORTED_MODULE_4__/* .addToCart */ .Xq)(cartItem).then(async (response)=>{
            if (response === null || response === void 0 ? void 0 : response.data) {
                const cartResponse = await (0,_adapters_cart__WEBPACK_IMPORTED_MODULE_4__/* .getCustomerCart */ .VQ)();
                dispatch((0,_redux_cart_cartActions__WEBPACK_IMPORTED_MODULE_5__/* .updateCart */ .xu)(cartResponse === null || cartResponse === void 0 ? void 0 : cartResponse.data));
                console.log("success");
            }
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "bg-white py-8 mb-8",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container mx-auto",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: "mx-2 mb-2 sm:hidden",
                    children: data === null || data === void 0 ? void 0 : data.product_name
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "grid grid-cols-10 gap-4",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-span-10 sm:col-span-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    alt: "image",
                                    src: (ref1 = currentVariant.images[0]) === null || ref1 === void 0 ? void 0 : ref1.url,
                                    width: "100%",
                                    height: "100%",
                                    layout: "responsive",
                                    objectFit: "contain"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-span-10 sm:col-span-5 px-2 sm:px-0",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "hidden sm:block",
                                        children: data === null || data === void 0 ? void 0 : data.product_name
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex justify-between sm:justify-start items-center mt-4 text-sm",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "mb-2 sm:mb-0 sm:mr-2",
                                                children: [
                                                    (data === null || data === void 0 ? void 0 : data.rating) > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: "fa-solid fa-star text-amber-500 mr-1"
                                                    }),
                                                    (data === null || data === void 0 ? void 0 : data.rating) > 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: "fa-solid fa-star text-amber-500 mr-1"
                                                    }),
                                                    (data === null || data === void 0 ? void 0 : data.rating) > 2 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: "fa-solid fa-star text-amber-500 mr-1"
                                                    }),
                                                    (data === null || data === void 0 ? void 0 : data.rating) > 3 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: "fa-solid fa-star text-amber-500 mr-1"
                                                    }),
                                                    (data === null || data === void 0 ? void 0 : data.rating) > 4 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: "fa-solid fa-star text-amber-500 mr-1"
                                                    }),
                                                    (data === null || data === void 0 ? void 0 : data.rating) == 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "bg-yellow-200 text-yellow-700 px-2 py-1 rounded-md shadow-sm",
                                                        children: "New"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "mr-3",
                                                children: (data === null || data === void 0 ? void 0 : data.rating) != 0 && (data === null || data === void 0 ? void 0 : data.rating)
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "mr-3",
                                                children: (data === null || data === void 0 ? void 0 : data.reviews.length) != 0 ? (data === null || data === void 0 ? void 0 : data.reviews.length) + " Reviews" : "No Reviews"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "mr-3",
                                                children: (data === null || data === void 0 ? void 0 : data.orders.length) != 0 ? (data === null || data === void 0 ? void 0 : data.orders.length) + " Orders" : "No Orders"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "font-semibold mt-4",
                                            children: data === null || data === void 0 ? void 0 : data.brand
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "border-y my-8 py-4",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "text-2xl font-semibold mr-4",
                                                    children: [
                                                        "BDT \u09F3",
                                                        parseInt(currentSize.pricing.special_price).toLocaleString()
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "line-through",
                                                    children: [
                                                        "BDT \u09F3",
                                                        parseInt(currentSize.pricing.price).toLocaleString()
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "ml-4 bg-red-200 text-red-600 px-2",
                                                    children: [
                                                        "-",
                                                        Math.round((parseInt(currentVariant.sizes[0].pricing.price) - parseInt(currentVariant.sizes[0].pricing.special_price)) * 100 / parseInt(currentVariant.sizes[0].pricing.price)),
                                                        "%"
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "mb-8",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                className: "mb-2",
                                                children: "Images: "
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "flex",
                                                children: currentVariant === null || currentVariant === void 0 ? void 0 : currentVariant.images.map((image, index)=>{
                                                    /*#__PURE__*/ return react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "h-16 w-16 border p-1 rounded mr-4 hover:cursor-pointer",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                                            alt: "image",
                                                            src: image === null || image === void 0 ? void 0 : image.url,
                                                            width: "100%",
                                                            height: "100%",
                                                            layout: "responsive",
                                                            objectFit: "contain"
                                                        })
                                                    }, index);
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "mb-8 flex",
                                        children: data === null || data === void 0 ? void 0 : data.variant_stock_price.map((variant, index)=>{
                                            /*#__PURE__*/ return react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                children: (currentVariant === null || currentVariant === void 0 ? void 0 : currentVariant.color_family) == variant.color_family ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    onClick: ()=>{
                                                        setCurrentVariant(variant);
                                                        setCurrentSize(variant === null || variant === void 0 ? void 0 : variant.sizes[0]);
                                                    },
                                                    className: "mr-2 bg-[#D23E41] text-white hover:cursor-pointer inline-block px-4 py-2 rounded ",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                        children: variant.color_family
                                                    })
                                                }, index) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    onClick: ()=>{
                                                        setCurrentVariant(variant);
                                                        setCurrentSize(variant === null || variant === void 0 ? void 0 : variant.sizes[0]);
                                                    },
                                                    className: "mr-2 bg-gray-100 hover:cursor-pointer inline-block px-4 py-2 rounded ",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                        children: variant.color_family
                                                    })
                                                }, index)
                                            }, index);
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "mb-8",
                                        children: currentVariant === null || currentVariant === void 0 ? void 0 : currentVariant.sizes.map((size, index)=>currentSize === size ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                onClick: ()=>setCurrentSize(size)
                                                ,
                                                className: "bg-[#D23E41] text-white font-semibold mr-3 hover:cursor-pointer inline-block px-2 py-1 rounded ",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                    children: size.size
                                                })
                                            }, index) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                onClick: ()=>setCurrentSize(size)
                                                ,
                                                className: "bg-gray-100 font-semibold mr-3 hover:cursor-pointer inline-block px-2 py-1 rounded ",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                    children: size.size
                                                })
                                            }, index)
                                        )
                                    }),
                                    onCart && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "mb-3",
                                                children: "Quantity: "
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex items-center",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "mr-4",
                                                        children: [
                                                            quantity > 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                onClick: ()=>(0,_redux_cart_cartActions__WEBPACK_IMPORTED_MODULE_5__/* .decQuantity */ .zm)(cart, onCart, dispatch)
                                                                ,
                                                                className: "fa-light fa-circle-minus text-2xl hover:cursor-pointer"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "text-2xl mx-2",
                                                                children: quantity
                                                            }),
                                                            (quantity < 5 || quantity < parseInt(currentSize.quantity)) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                onClick: ()=>(0,_redux_cart_cartActions__WEBPACK_IMPORTED_MODULE_5__/* .incQuantity */ .PS)(cart, onCart, dispatch)
                                                                ,
                                                                className: "fa-light fa-circle-plus text-2xl hover:cursor-pointer"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        children: [
                                                            "In Stock: ",
                                                            currentSize.quantity
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "mt-4",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "grid grid-cols-2 gap-2 sm:block",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    onClick: ()=>dispatch((0,_adapters_cart__WEBPACK_IMPORTED_MODULE_4__/* .addToCart */ .Xq)({
                                                            ...data,
                                                            quantity
                                                        }))
                                                    ,
                                                    className: "w-full sm:w-auto col-span-1 hover:shadow-md text-white px-4 py-2 sm:px-16 bg-gradient-to-r from-violet-500 to-fuchsia-500 mr-4 sm:p-4 font-semibold rounded-md",
                                                    children: "Buy Now"
                                                }),
                                                !onCart ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    onClick: handleAddToCart,
                                                    className: "w-full sm:w-auto col-span-1 hover:shadow-md text-white sm:px-16 bg-gradient-to-r from-sky-500 to-indigo-500 mr-4 px-4 py-2 sm:p-4 font-semibold rounded-md focus:shadow-md transition-all duration-200",
                                                    children: "Add to Cart"
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    onClick: ()=>{
                                                        (0,_redux_cart_cartActions__WEBPACK_IMPORTED_MODULE_5__/* .removeItem */ .cl)(cart, onCart, dispatch);
                                                        setQuentity(1);
                                                    },
                                                    className: "w-full sm:w-auto col-span-1 hover:shadow-md text-white px-4 py-2 sm:px-16 bg-gradient-to-r from-sky-500 to-indigo-500 mr-4 sm:p-4 font-semibold rounded-md focus:shadow-md transition-all duration-200",
                                                    children: "Remove"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                    className: "col-span-2 border py-2 px-4 sm:p-4 rounded-md",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                            className: "fa-light fa-heart mr-1"
                                                        }),
                                                        "15.8K"
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mt-4 flex mx-2 sm:mx-0",
                    children: data === null || data === void 0 ? void 0 : data.variant_stock_price.map((varient, index)=>{
                        var ref;
                        /*#__PURE__*/ return react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            onClick: ()=>setCurrentVariant(varient)
                            ,
                            className: "h-20 w-20 border p-1 rounded mr-4 hover:cursor-pointer",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                alt: "image",
                                src: (ref = varient === null || varient === void 0 ? void 0 : varient.images[0]) === null || ref === void 0 ? void 0 : ref.url,
                                width: "100%",
                                height: "100%",
                                layout: "responsive",
                                objectFit: "contain"
                            })
                        }, index);
                    })
                })
            ]
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3918:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Reviews)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function Reviews() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "container mx-auto bg-white my-8 p-4 rounded-lg shadow-md",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "text-center text-xl border-b pb-4",
                children: "Reviews"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                            className: "",
                            children: "Customer Reviews (170)"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: "5 Starts"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {})
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};


/***/ }),

/***/ 5220:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ TopBar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);



function TopBar() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "bg-[#FAFAFA] py-4",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container mx-auto",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                    className: "flex px-2 sm:px-0 justify-between sm:justify-start items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "sm:mr-8",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                passHref: true,
                                href: "/",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                    className: "sm:text-xl font-semibold text-gray-500 hover:cursor-pointer",
                                    children: "Store Home"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "sm:mr-8 hidden sm:block",
                            children: "93.0% Positive feedback"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "sm:mr-8 text-sm sm:text-md",
                            children: "1335 Followers"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "sm:mr-8",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "bg-gradient-to-r from-purple-500 to-pink-500 px-2 py-1 text-sm sm:text-md sm:px-8 sm:py-2 text-white rounded-full shadow-sm",
                                children: "Follow"
                            })
                        })
                    ]
                })
            })
        })
    });
};


/***/ }),

/***/ 3015:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ productDetail),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _adapters_product__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9113);
/* harmony import */ var _components_product_TopBar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5220);
/* harmony import */ var _components_product_HeroSection__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5371);
/* harmony import */ var _components_product_Description__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9984);
/* harmony import */ var _components_product_Reviews__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3918);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_adapters_product__WEBPACK_IMPORTED_MODULE_2__, _components_product_HeroSection__WEBPACK_IMPORTED_MODULE_4__, _components_product_Description__WEBPACK_IMPORTED_MODULE_5__]);
([_adapters_product__WEBPACK_IMPORTED_MODULE_2__, _components_product_HeroSection__WEBPACK_IMPORTED_MODULE_4__, _components_product_Description__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







function productDetail({ product  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "mt-[48px]",
        children: product && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_TopBar__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    data: product
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_HeroSection__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    data: product
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_Description__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    data: product
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_Reviews__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    data: product
                })
            ]
        })
    });
};
async function getStaticPaths() {
    const response = await (0,_adapters_product__WEBPACK_IMPORTED_MODULE_2__/* .AllProducts */ .c)();
    const products = response.data;
    const paths = products.map((product)=>{
        return {
            params: {
                slug: product.slug
            }
        };
    });
    return {
        paths,
        fallback: "blocking"
    };
}
async function getStaticProps(context) {
    const { params  } = context;
    console.log("params: ", params);
    const response = await (0,_adapters_product__WEBPACK_IMPORTED_MODULE_2__/* .SingleProduct */ .bm)(`product/${params.slug}`);
    console.log("product data: ", response.data);
    return {
        props: {
            product: response.data
        },
        revalidate: 10
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 4241:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/routing-items.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2905:
/***/ ((module) => {

module.exports = import("html-react-parser");;

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [397,676,664,675,673,745], () => (__webpack_exec__(3015)));
module.exports = __webpack_exports__;

})();