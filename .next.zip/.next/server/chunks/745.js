"use strict";
exports.id = 745;
exports.ids = [745];
exports.modules = {

/***/ 1903:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VQ": () => (/* binding */ getCustomerCart),
/* harmony export */   "Xq": () => (/* binding */ addToCart),
/* harmony export */   "gZ": () => (/* binding */ updateCartOnDB)
/* harmony export */ });
/* unused harmony exports deleteCart, updateCartItem, deleteCartItem, deleteCartAllItem */
/* harmony import */ var _xhr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4673);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_xhr__WEBPACK_IMPORTED_MODULE_0__]);
_xhr__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

function getCustomerCart() {
    return (0,_xhr__WEBPACK_IMPORTED_MODULE_0__/* .Get */ .dX)("customer/cart/");
}
function addToCart(data) {
    return (0,_xhr__WEBPACK_IMPORTED_MODULE_0__/* .Post */ .SO)("customer/add-to-cart", data);
}
function updateCartOnDB(id, data) {
    return (0,_xhr__WEBPACK_IMPORTED_MODULE_0__/* .Update */ .BN)(`customer/update-cart/${id}`, data);
}
function deleteCart(id) {
    return Delete(`customer/delete-cart/${id}`);
}
function updateCartItem(item) {
    return Update(`customer/update-cart-item/`, item);
}
function deleteCartItem(item) {
    return Delete(`customer/delete-cart-item/`, item);
}
function deleteCartAllItem() {
    return Delete("customer/delete-cart-all-items/");
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5745:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "xu": () => (/* binding */ updateCart),
/* harmony export */   "PS": () => (/* binding */ incQuantity),
/* harmony export */   "zm": () => (/* binding */ decQuantity),
/* harmony export */   "a3": () => (/* binding */ updateCartItemQuantity),
/* harmony export */   "cl": () => (/* binding */ removeItem)
/* harmony export */ });
/* unused harmony exports addToCart, removeFromCart, increaseSingleQuantity, decreaseSingleQuantity, updateCartItem */
/* harmony import */ var _adapters_cart__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1903);
/* harmony import */ var _cartTypes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8519);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_adapters_cart__WEBPACK_IMPORTED_MODULE_0__]);
_adapters_cart__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const addToCart = (data)=>{
    return {
        type: ADD_TO_CART,
        payload: data
    };
};
const removeFromCart = (data)=>{
    return {
        type: REMOVE_FROM_CART,
        payload: data
    };
};
const increaseSingleQuantity = (data)=>{
    return {
        type: INCREASE_SINGLE_QUANTITY,
        payload: data
    };
};
const decreaseSingleQuantity = (data)=>{
    return {
        type: DECREASE_SINGLE_QUANTITY,
        payload: data
    };
};
const updateCart = (data)=>{
    return {
        type: _cartTypes__WEBPACK_IMPORTED_MODULE_1__/* .UPDATE_TO_CART */ .um,
        payload: data
    };
};
const incQuantity = (cart, item, dispatch)=>{
    var ref;
    const incData = cart === null || cart === void 0 ? void 0 : (ref = cart.items) === null || ref === void 0 ? void 0 : ref.map((product)=>{
        if ((product === null || product === void 0 ? void 0 : product.slug) == (item === null || item === void 0 ? void 0 : item.slug)) {
            return {
                ...product,
                quantity: parseInt(product.quantity) + 1
            };
        } else {
            return product;
        }
    });
    (0,_adapters_cart__WEBPACK_IMPORTED_MODULE_0__/* .updateCartOnDB */ .gZ)(cart === null || cart === void 0 ? void 0 : cart._id, {
        ...cart,
        items: incData
    }).then((response)=>{
        dispatch(updateCart(response.data));
    });
};
const decQuantity = (cart, item, dispatch)=>{
    var ref;
    const decData = cart === null || cart === void 0 ? void 0 : (ref = cart.items) === null || ref === void 0 ? void 0 : ref.map((product)=>{
        if ((product === null || product === void 0 ? void 0 : product.slug) == (item === null || item === void 0 ? void 0 : item.slug)) {
            return {
                ...product,
                quantity: parseInt(product.quantity) - 1
            };
        } else {
            return product;
        }
    });
    (0,_adapters_cart__WEBPACK_IMPORTED_MODULE_0__/* .updateCartOnDB */ .gZ)(cart === null || cart === void 0 ? void 0 : cart._id, {
        ...cart,
        items: decData
    }).then((response)=>{
        dispatch(updateCart(response.data));
    });
};
const updateCartItemQuantity = (cart, item, qty, dispatch)=>{
    var ref;
    const decData = cart === null || cart === void 0 ? void 0 : (ref = cart.items) === null || ref === void 0 ? void 0 : ref.map((product)=>{
        if ((product === null || product === void 0 ? void 0 : product.slug) == (item === null || item === void 0 ? void 0 : item.slug)) {
            return {
                ...product,
                quantity: parseInt(qty)
            };
        } else {
            return product;
        }
    });
    (0,_adapters_cart__WEBPACK_IMPORTED_MODULE_0__/* .updateCartOnDB */ .gZ)(cart === null || cart === void 0 ? void 0 : cart._id, {
        ...cart,
        items: decData
    }).then((response)=>{
        dispatch(updateCart(response.data));
    });
};
const updateCartItem = (cart, item, qty, dispatch)=>{
    var ref;
    const decData = cart === null || cart === void 0 ? void 0 : (ref = cart.items) === null || ref === void 0 ? void 0 : ref.map((product)=>{
        if ((product === null || product === void 0 ? void 0 : product.slug) == (item === null || item === void 0 ? void 0 : item.slug)) {
            return {
                ...product,
                quantity: parseInt(qty)
            };
        } else {
            return product;
        }
    });
    updateCartOnDB(cart === null || cart === void 0 ? void 0 : cart._id, {
        ...cart,
        items: decData
    }).then((response)=>{
        dispatch(updateCart(response.data));
    });
};
const removeItem = (cart, item, dispatch)=>{
    var ref;
    const rmData = cart === null || cart === void 0 ? void 0 : (ref = cart.items) === null || ref === void 0 ? void 0 : ref.filter((product)=>{
        return (product === null || product === void 0 ? void 0 : product.slug) != (item === null || item === void 0 ? void 0 : item.slug);
    });
    (0,_adapters_cart__WEBPACK_IMPORTED_MODULE_0__/* .updateCartOnDB */ .gZ)(cart === null || cart === void 0 ? void 0 : cart._id, {
        ...cart,
        items: rmData
    }).then((response)=>{
        dispatch(updateCart(response.data));
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8519:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G2": () => (/* binding */ ADD_TO_CART),
/* harmony export */   "OZ": () => (/* binding */ REMOVE_FROM_CART),
/* harmony export */   "um": () => (/* binding */ UPDATE_TO_CART),
/* harmony export */   "H0": () => (/* binding */ INCREASE_SINGLE_QUANTITY),
/* harmony export */   "qQ": () => (/* binding */ DECREASE_SINGLE_QUANTITY)
/* harmony export */ });
/* unused harmony export REFRESH_CART */
const ADD_TO_CART = "ADD_TO_CART";
const REMOVE_FROM_CART = "REMOVE_FROM_CART";
const UPDATE_TO_CART = "UPDATE_TO_CART";
const INCREASE_SINGLE_QUANTITY = "INCREASE_SINGLE_QUANTITY";
const DECREASE_SINGLE_QUANTITY = "DECREASE_SINGLE_QUANTITY";
const REFRESH_CART = "REFRESH_CART";


/***/ })

};
;