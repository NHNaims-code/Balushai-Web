"use strict";
exports.id = 673;
exports.ids = [673];
exports.modules = {

/***/ 4673:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dX": () => (/* binding */ Get),
/* harmony export */   "SO": () => (/* binding */ Post),
/* harmony export */   "BN": () => (/* binding */ Update)
/* harmony export */ });
/* unused harmony export Delete */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5936);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_constants__WEBPACK_IMPORTED_MODULE_1__]);
_constants__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


function returnAxiosInstance() {
    return axios__WEBPACK_IMPORTED_MODULE_0___default().create();
}
function Get(path) {
    const axios = returnAxiosInstance();
    return axios.get(`${_constants__WEBPACK_IMPORTED_MODULE_1__/* .baseUrl */ .FH}/${path}`, {
        withCredentials: true
    }, _constants__WEBPACK_IMPORTED_MODULE_1__/* .headerOptions */ .Bn);
}
function Post(path, requestData) {
    const axios = returnAxiosInstance();
    return axios.post(`${_constants__WEBPACK_IMPORTED_MODULE_1__/* .baseUrl */ .FH}/${path}`, requestData, {
        withCredentials: true
    }, _constants__WEBPACK_IMPORTED_MODULE_1__/* .headerOptions */ .Bn);
}
function Update(path, updateData) {
    const axios = returnAxiosInstance();
    return axios.patch(`${_constants__WEBPACK_IMPORTED_MODULE_1__/* .baseUrl */ .FH}/${path}`, updateData, {
        withCredentials: true
    }, _constants__WEBPACK_IMPORTED_MODULE_1__/* .headerOptions */ .Bn);
}
function Delete(path, data) {
    const axios = returnAxiosInstance();
    return axios.delete(`${baseUrl}/${path}`, data, {
        withCredentials: true
    }, headerOptions);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5936:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Bn": () => (/* binding */ headerOptions),
/* harmony export */   "FH": () => (/* binding */ baseUrl),
/* harmony export */   "Lx": () => (/* binding */ customer)
/* harmony export */ });
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9915);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_0__]);
js_cookie__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const headerOptions = {
    Accept: "application/json",
    "Content-Type": "application/json"
}, customer = js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].get("token"), baseUrl = "https://api.balushai.com";


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;