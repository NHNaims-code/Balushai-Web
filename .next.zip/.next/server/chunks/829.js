"use strict";
exports.id = 829;
exports.ids = [829];
exports.modules = {

/***/ 3084:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ ErrorToast)
/* harmony export */ });
/* unused harmony export SuccessToast */
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_0__);

const options = {
    position: "top-right",
    autoClose: 2000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: false,
    draggable: true,
    progress: undefined,
    toastId: "1234"
};
const ErrorToast = (msg)=>{
    react_toastify__WEBPACK_IMPORTED_MODULE_0__.toast.error(msg, options);
};
const SuccessToast = (msg)=>{
    toast.success(msg, options);
};



/***/ }),

/***/ 6976:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": () => (/* binding */ TryCatch)
/* harmony export */ });
/* harmony import */ var _Error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3084);

async function TryCatch(fn) {
    try {
        await fn();
    } catch (error) {
        /* if(error.response?.status === 401 || error.response?.status === 403){
            ErrorToast('Authorized') ;
            //Cookies?.remove('vendor', { path: '/' })
            //window.location.href = ('/#/sign-in');
        } */ console.log(error.response);
        if (error === null || error === void 0 ? void 0 : error.response) {
            var ref, ref1;
            return (ref = error.response) === null || ref === void 0 ? void 0 : (ref1 = ref.data) === null || ref1 === void 0 ? void 0 : ref1.err;
        // ErrorToast(error.response?.data?.err) ;
        // console.log("R error: ", error.response?.data?.err)
        } else {
            console.log(error);
            (0,_Error__WEBPACK_IMPORTED_MODULE_0__/* .ErrorToast */ .P)("Something went wrong");
            return 0;
        }
    }
}
;


/***/ }),

/***/ 3829:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "pT": () => (/* reexport safe */ _TryCatchHandle__WEBPACK_IMPORTED_MODULE_0__.p)
/* harmony export */ });
/* harmony import */ var _TryCatchHandle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6976);
/* harmony import */ var _Error__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3084);
/* harmony import */ var _setCookie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6360);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_setCookie__WEBPACK_IMPORTED_MODULE_2__]);
_setCookie__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6360:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* unused harmony export CookieSet */
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9915);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_0__]);
js_cookie__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const ONE_DAY = 1;
const CookieSet = (res)=>{
    Cookies.set("vendor", res.data.token, {
        expires: ONE_DAY,
        path: "/",
        secure: true,
        sameSite: "None"
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;